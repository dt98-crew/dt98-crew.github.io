﻿ Dokucraft: The Saga Continues
═══════════════════════════════════════════════════════════════════════
 Website:
	https://dokucraft.co.uk
═══════════════════════════════════════════════════════════════════════
 Discord Server:
	https://dokucraft.co.uk/discord
═══════════════════════════════════════════════════════════════════════
 Terms of Use:
 	https://dokucraft.co.uk/terms
═══════════════════════════════════════════════════════════════════════
 Installation Instructions:
   	   !!Make sure to download the correct Pack for your
         Minecraft version to avoid compatibility issues!!

	1.
	   In order to use this pack properly you need to use
	   the Optifine to get the full pack experience.

	   Downloads for Optifine:
			optifine.net

	   When using optifine make sure that connected textures
	   is enabled in the video settings.
			(options/videosettings/Quality)

	2.
 	   Now go into your game open the Resource pack
	   selection screen and click on open resource pack
	   folder and drag Dokucraft.zip there.

 	3.
	   Now select Dokucraft in the resource pack menu
	   and move it to selected packs hit done and wait
	   for the game to load the textures.
═══════════════════════════════════════════════════════════════════════
 	Please, share this texture pack by using the original
	URL and don't host/mirror it without permission.

 Enjoy!
	Dokucraft
═══════════════════════════════════════════════════════════════════════