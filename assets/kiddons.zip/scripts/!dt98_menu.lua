-- DT98 GTA Menu Script
-- Text Function
local function Text(text)
	menu.add_action(text, function() end)
end

-- Main Scripts Menu Items
Text(" 🤠 🤠 Dos Tres Amigoz Mods 🤠 🤠")
